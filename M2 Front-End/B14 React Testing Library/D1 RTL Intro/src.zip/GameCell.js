import React from 'react';
import PropTypes from 'prop-types';
import './GameCell.css';
import xImage from './x.png';
import oImage from './o.svg';

// Não mude a propriedade da div data-testid de cada casa
// ele será utilizado para o terceiro exercício!
// Use-o para selecionar uma casa especifica nas horas dos testes.

class GameCell extends React.Component {
  render() {
    const { id, content, onClick } = this.props;

    if (content === 1) {
      return (
        <div
          aria-label="Cell"
          className="game-cell"
          data-testid={`cell_${id}`}
          onClick={onClick}
          onKeyPress={onClick}
          role="button"
          tabIndex="0"
        >
          <img data-testid={`cell_${id}_image`} alt="X" src={xImage} />
        </div>
      );
    }

    if (content === 2) {
      return (
        <div
          aria-label="Cell"
          className="game-cell"
          data-testid={`cell_${id}`}
          onClick={onClick}
          onKeyPress={onClick}
          tabIndex="0"
        >
          <img data-testid={`cell_${id}_image`} alt="O" src={oImage} />
        </div>
      );
    }

    return (
      <div
        aria-label="Cell"
        className="game-cell"
        data-testid={`cell_${id}`}
        key={id}
        onClick={onClick}
        onKeyPress={onClick}
        role="button"
        tabIndex="0"
      />
    );
  }
}

GameCell.propTypes = {
  content: PropTypes.oneOf([0, 1, 2]),
  onClick: PropTypes.func.isRequired,
  id: PropTypes.number.isRequired,
};

GameCell.defaultProps = {
  content: 0,
};

export default GameCell;
